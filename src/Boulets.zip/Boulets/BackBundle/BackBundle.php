<?php

namespace Boulets\BackBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BackBundle extends Bundle
{
}
