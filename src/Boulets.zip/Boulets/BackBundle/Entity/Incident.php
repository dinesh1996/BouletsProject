<?php

    namespace Boulets\BackBundle\Entity;

    use Doctrine\ORM\Mapping as ORM;

    /**
     * Incident
     *
     * @ORM\Table(name="incident")
     * @ORM\Entity(repositoryClass="Boulets\BackBundle\Repository\IncidentRepository")
     */
    class Incident
    {



        /**
         * @var int
         *
         * @ORM\Column(name="id", type="integer")
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="AUTO")
         */
        private $id;


        /**
         * @var string
         *
         * @ORM\Column(name="ip", type="string", length=15)
         */
        private $ip;

        /**
         * @return string
         */
        public function getIp()
        {
            return $this->ip;
        }

        /**
         * @param string $ip
         */
        public function setIp($ip)
        {
            $this->ip = $ip;
        }










        /**
         * @var string
         *
         * @ORM\Column(name="nom", type="string", length=50)
         */
        private $nom;

        /**
         * @var string
         *
         * @ORM\Column(name="type", type="string", length=50)
         */
        private $type;

        /**
         * @var string
         *
         * @ORM\Column(name="text", type="string", length=5000)
         */
        private $text;

        /**
         * @var string
         *
         * @ORM\Column(name="machine", type="string", length=50)
         */
        private $machine;

        /**
         * @var \DateTime
         *
         * @ORM\Column(name="datedebut", type="datetime")
         */
        private $datedebut;

        /**
         * @var \DateTime
         *
         * @ORM\Column(name="datefin", type="datetime")
         */
        private $datefin;



        /**
         * @var \string
         *
         * @ORM\Column(name="salle", type="string")
         */
        private $salle;

        /**
         * @return string
         */
        public function getSalle()
        {
            return $this->salle;
        }

        /**
         * @param string $salle
         */
        public function setSalle($salle)
        {
            $this->salle = $salle;
        }

        /**
         * Get id
         *
         * @return int
         */
        public function getId()
        {
            return $this->id;
        }

        /**
         * Set nom
         *
         * @param string $nom
         *
         * @return Incident
         */
        public function setNom($nom)
        {
            $this->nom = $nom;

            return $this;
        }

        /**
         * Get nom
         *
         * @return string
         */
        public function getNom()
        {
            return $this->nom;
        }

        /**
         * Set type
         *
         * @param string $type
         *
         * @return Incident
         */
        public function setType($type)
        {
            $this->type = $type;

            return $this;
        }

        /**
         * Get type
         *
         * @return string
         */
        public function getType()
        {
            return $this->type;
        }

        /**
         * Set text
         *
         * @param string $text
         *
         * @return Incident
         */
        public function setText($text)
        {
            $this->text = $text;

            return $this;
        }

        /**
         * Get text
         *
         * @return string
         */
        public function getText()
        {
            return $this->text;
        }

        /**
         * Set machine
         *
         * @param string $machine
         *
         * @return Incident
         */
        public function setMachine($machine)
        {
            $this->machine = $machine;

            return $this;
        }

        /**
         * Get machine
         *
         * @return string
         */
        public function getMachine()
        {
            return $this->machine;
        }

        /**
         * Set datedebut
         *
         * @param \DateTime $datedebut
         *
         * @return Incident
         */
        public function setDatedebut($datedebut)
        {
            $this->datedebut = $datedebut;

            return $this;
        }

        /**
         * Get datedebut
         *
         * @return \DateTime
         */
        public function getDatedebut()
        {
            return $this->datedebut;
        }

        /**
         * Set datefin
         *
         * @param \DateTime $datefin
         *
         * @return Incident
         */
        public function setDatefin($datefin)
        {
            $this->datefin = $datefin;

            return $this;
        }

        /**
         * Get datefin
         *
         * @return \DateTime
         */
        public function getDatefin()
        {
            return $this->datefin;
        }
    }

